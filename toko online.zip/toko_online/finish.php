<?
$kd_transaksi = $_GET['kd_transaksi'];

	$totalBayar = $_GET['total_bayar'];?>

<h3> Selamat,Transaksi sukses di lakukan</h2>
<h3> Kode Pesan :<?=$kd_transaksi;?></h2>
<h3>Total Harga :<?=$totalBayar;?></h2>


</h2>
<p>
	Silahkan transfer uang ke
</p>
<blockquote>
	Candra Adi putra
	<br>
	BNI Syariah Yogyakarta
	<br>
	No Rek 12345678
	<br>
</blockquote>
<hr>
<p>
	Konfirmasi pembayaran dapat anda lakukan di menu konfirmasi pembayaran, setelah anda melakukan
	Transfer uang ke rekening kami
</p>
