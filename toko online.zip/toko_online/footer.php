
<div class="cleared"></div>
</div><!-- id="wrapper" -->
<div id="footer">

    <div class="cleared"></div><br>



</div><!-- footer -->
 <style>
#find{
     background:#444;
	 color:#fff;
    height:122px;
    width:100%;
    padding-top:10px;
	
   
}
#top{
    margin-left:4px;
    margin-bottom:6px;
    width:30px;
    float:left;

}


</style>
<div id="find">
<center>
Copyright &#169; <script type='text/javascript'>var creditsyear = new Date();document.write(creditsyear.getFullYear());</script>&nbsp Developed & Maintenance by &nbsp; <a href='#'>king
</center>
</div>

<!-- 
Owner: Pahmi Ritonga
Email; pahmiritonga@gmail.com
Web : www.eternysoft.com
Blog : www.bangpahmi.com
Twitter :@PahmiRitonga90

 -->

