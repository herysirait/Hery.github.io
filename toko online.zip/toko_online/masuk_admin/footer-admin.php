<div id="foot_admin">

<style>
#bgfoot_admin{
    background:#333;
    width:100%;
    height:auto;
}
</style>
<div id="bgfoot_admin>
<center><small>Powered By Pahmi Ritonga</small></center>
</div>

</div>


</body>
</html>
