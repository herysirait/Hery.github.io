

<div id="footer">
<div id="find">
<center>
<small> Copyright &#169;<script type='text/javascript'>var creditsyear = new Date();document.write(creditsyear.getFullYear());</script>&nbsp;Sasando.co.id
Design & Maintenance by &nbsp;<a href='#'>Pahmi Ritonga</a></small></center>
</div>
</div>

</div>
</div>