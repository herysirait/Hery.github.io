<?php
// http://www.facebook.com/share.php?u=url
 //http://twitter.com/home/?status=url
 //http://digg.com/submit?url=url
// https://plus.google.com/submit?url=url
?>
<div id="share">
Bagikan Artikel ini pada:
<script language="javascript">
document.write("<a href='http://twitter.com/home/?status=" + document.URL + "'><img src='images/twit.png'></a>&nbsp;<a href='http://www.facebook.com/share.php?u=" + document.URL + "'><img src='images/fb.png'></a>&nbsp;<a href='https://plus.google.com/submit?url=" + document.URL + "'><img src='images/pls.png'></a>&nbsp;<a href='http://digg.com/submit?url=" + document.URL + "'><img src='images/dig.png'></a>");
</script>
</div>
