<!doctype html public "-//W3C//DTD HTML 4.0 //EN"> 
<html>
<head>
       <title>Title here!</title>
</head>
<body>
<style>
#menu{
}
</style>
       <div id="menu">
       <ul>
          <li><a href="#">Home</a></li>
           <li><a href="#">Home</a></li>
            <li><a href="#">Home</a></li>
             <li><a href="#">Home</a></li>
       </ul>
       </div>
</body>
</html>
